# Quiz de Porcentagem

Um quiz simples, em português, para praticar cálculos básicos de porcentagem.

## Como abrir

1. Baixe ou clone este repositório.
2. Abra o arquivo `index.html` em qualquer navegador moderno.
3. Responda às cinco perguntas e leia as explicações.

Não é necessário instalar programas, usar servidor ou criar uma conta.

## Como contribuir

Ideias para melhorias:

- adicionar novas perguntas;
- criar níveis de dificuldade;
- incluir outros assuntos de matemática;
- melhorar a acessibilidade e o visual.

Para adicionar perguntas, edite a lista `questions` no final de `index.html`. Cada item possui `text`, `options`, `answer` (posição da alternativa correta, começando em zero) e `explanation`.

## Licença

Este projeto está disponível sob a licença MIT. Consulte o arquivo `LICENSE`.
